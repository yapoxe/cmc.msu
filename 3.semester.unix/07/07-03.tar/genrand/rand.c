#include <stdlib.h>
int 
rand_range(int low, int high)
{
    int a;
    double b;
    b = rand() / (RAND_MAX + 1.0);
    a = (int) (b * (high - low)) + low;
    return a;
}